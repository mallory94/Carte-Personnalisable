Hi, and thanks for your interest in contributing to leaflet-osm.

To run the leaflet-osm tests:

```
$ npm install
$ npm test
```

Add tests for bugfixes and new features to `test/osm_test.js`. It uses [mocha](http://visionmedia.github.io/mocha/)
and [chai](http://chaijs.com/).
